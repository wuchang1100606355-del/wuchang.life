"""Packet-carried prerequisite and equivalent-state verification."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .canonical import sha256_bytes, verify_packet_sha256
from .errors import PreconditionMissing, VerificationError
from .model import validate_packet
from .store import ContentStore


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _reference_map(packet: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        item["ref_id"]: item for item in packet["d5_resource"]["references"]
    }


def preflight_packet(packet: dict[str, Any], store: ContentStore) -> dict[str, Any]:
    validate_packet(packet)
    packet_digest = verify_packet_sha256(packet)
    now = datetime.now(timezone.utc)
    created_raw = packet["d8_envelope"]["created_at"]
    created = datetime.fromisoformat(created_raw[:-1] + "+00:00")
    if created > now:
        raise VerificationError(f"packet creation time is in the future: {created_raw}")
    expires_raw = packet["d8_envelope"].get("expires_at")
    if expires_raw is not None:
        expires = datetime.fromisoformat(expires_raw[:-1] + "+00:00")
        if expires <= now:
            raise VerificationError(f"packet expired at {expires_raw}")
    missing: list[str] = []
    checked: list[dict[str, Any]] = []
    for reference in packet["d5_resource"]["references"]:
        if reference.get("disclosure", "resolvable") == "reference_only":
            checked.append({"ref_id": reference["ref_id"], "status": "REFERENCE_ONLY"})
            continue
        available = store.has(reference)
        checked.append({"ref_id": reference["ref_id"], "status": "PASS" if available else "MISSING"})
        if reference["required"] and not available:
            missing.append(reference["ref_id"])
    if missing:
        raise PreconditionMissing(f"required references unavailable: {sorted(missing)}")
    return {
        "state": "PASS_PREFLIGHT",
        "packet_id": packet["d8_envelope"]["packet_id"],
        "packet_sha256": packet_digest,
        "checked_at": _now(),
        "temporal_validity": "PASS",
        "references": checked,
    }


def _safe_target(root: Path, relative: str) -> Path:
    root_resolved = root.resolve()
    target = (root_resolved / relative).resolve()
    if target != root_resolved and root_resolved not in target.parents:
        raise VerificationError(f"verification path escapes target root: {relative}")
    return target


def _json_pointer(value: Any, pointer: str) -> Any:
    if pointer == "":
        return value
    current = value
    for raw_token in pointer.split("/")[1:]:
        token = raw_token.replace("~1", "/").replace("~0", "~")
        if isinstance(current, list):
            try:
                current = current[int(token)]
            except (ValueError, IndexError) as exc:
                raise VerificationError(f"JSON pointer segment not found: {token}") from exc
        elif isinstance(current, dict) and token in current:
            current = current[token]
        else:
            raise VerificationError(f"JSON pointer segment not found: {token}")
    return current


def verify_reconstruction(packet: dict[str, Any], target_root: str | Path) -> dict[str, Any]:
    validate_packet(packet)
    packet_digest = verify_packet_sha256(packet)
    root = Path(target_root)
    if not root.is_dir():
        raise VerificationError(f"reconstruction root is unavailable: {root}")
    results: list[dict[str, Any]] = []
    failures: list[str] = []
    checks = packet["d7_verification"]["equivalence_checks"]
    for check in checks:
        target = _safe_target(root, check["path"])
        status = "PASS"
        observed: Any
        try:
            if check["type"] == "path_exists":
                observed = target.exists()
                if not observed:
                    raise VerificationError("path is missing")
            elif check["type"] == "file_sha256":
                if not target.is_file():
                    raise VerificationError("file is missing")
                observed = sha256_bytes(target.read_bytes())
                if observed != check["sha256"]:
                    raise VerificationError(f"digest mismatch: {observed}")
            elif check["type"] == "json_pointer_equals":
                if not target.is_file():
                    raise VerificationError("JSON file is missing")
                try:
                    document = json.loads(target.read_text(encoding="utf-8"))
                except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise VerificationError(f"invalid JSON: {exc}") from exc
                observed = _json_pointer(document, check["pointer"])
                if observed != check["expected"]:
                    raise VerificationError(f"value mismatch: {observed!r}")
            else:  # guarded by validate_packet
                raise VerificationError(f"unsupported check: {check['type']}")
        except VerificationError as exc:
            status = "FAIL"
            observed = str(exc)
            failures.append(check["check_id"])
        results.append(
            {
                "check_id": check["check_id"],
                "type": check["type"],
                "status": status,
                "observed": observed,
            }
        )
    if failures:
        raise VerificationError(f"equivalent-state checks failed: {failures}")
    return {
        "state": "PASS_EQUIVALENT_STATE_VERIFIED",
        "acceptance_model": packet["d7_verification"]["acceptance_model"],
        "packet_id": packet["d8_envelope"]["packet_id"],
        "packet_sha256": packet_digest,
        "verified_at": _now(),
        "checks": results,
    }
