class PacketError(Exception):
    """Base class for packet failures."""


class PacketValidationError(PacketError):
    """The packet violates its schema or governance invariants."""


class IntegrityError(PacketError):
    """A packet or referenced object failed its digest contract."""


class PreconditionMissing(PacketError):
    """A declared receiver prerequisite is unavailable."""


class GovernanceDenied(PacketError):
    """The requested receiver action is not authorized by the packet."""


class UnsafeTargetError(PacketError):
    """Reconstruction would overwrite or escape its distinct target."""


class VerificationError(PacketError):
    """The reconstructed state does not satisfy packet-carried checks."""

