"""Structured command-line interface for packet build and receive flows."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Sequence

from .builder import build_packet
from .canonical import verify_packet_sha256
from .errors import PacketError
from .io import atomic_write_json, load_json
from .model import validate_packet
from .receiver import reconstruct_packet
from .replay import ReplayGuard
from .store import ContentStore
from .verifier import preflight_packet, verify_reconstruction


def _print(value: Any, *, stream: Any = sys.stdout) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")), file=stream)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="w7tp-packet")
    sub = parser.add_subparsers(dest="command", required=True)

    build = sub.add_parser("build", help="validate and seal a full 8D packet specification")
    build.add_argument("--spec", required=True)
    build.add_argument("--output", required=True)

    validate = sub.add_parser("validate", help="validate schema and envelope integrity")
    validate.add_argument("packet")

    put = sub.add_parser("store-put", help="place one prerequisite into the content store")
    put.add_argument("--store", required=True)
    put.add_argument("--file", required=True)
    put.add_argument("--ref-id", required=True)
    put.add_argument("--media-type", default="application/octet-stream")

    preflight = sub.add_parser("preflight", help="resolve packet prerequisites without reconstruction")
    preflight.add_argument("packet")
    preflight.add_argument("--store", required=True)

    reconstruct = sub.add_parser("reconstruct", help="reconstruct into a new or empty receiver target")
    reconstruct.add_argument("packet")
    reconstruct.add_argument("--store", required=True)
    reconstruct.add_argument("--target", required=True)
    reconstruct.add_argument("--replay-dir", required=True)
    reconstruct.add_argument("--receipt", required=True)

    verify = sub.add_parser("verify", help="rerun packet-carried equivalent-state checks")
    verify.add_argument("packet")
    verify.add_argument("--target", required=True)
    verify.add_argument("--receipt", required=True)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "build":
            packet = build_packet(load_json(args.spec))
            atomic_write_json(args.output, packet)
            _print({"state": "PASS_PACKET_BUILT", "output": str(Path(args.output)), "packet_sha256": verify_packet_sha256(packet)})
        elif args.command == "validate":
            packet = load_json(args.packet)
            validate_packet(packet)
            _print({"state": "PASS_PACKET_VALID", "packet_id": packet["d8_envelope"]["packet_id"], "packet_sha256": verify_packet_sha256(packet)})
        elif args.command == "store-put":
            reference = ContentStore(args.store).put_file(args.file, ref_id=args.ref_id, media_type=args.media_type)
            _print({"state": "PASS_REFERENCE_STORED", "reference": reference})
        elif args.command == "preflight":
            _print(preflight_packet(load_json(args.packet), ContentStore(args.store)))
        elif args.command == "reconstruct":
            receipt = reconstruct_packet(
                load_json(args.packet), ContentStore(args.store), args.target, ReplayGuard(args.replay_dir)
            )
            atomic_write_json(args.receipt, receipt)
            _print({"state": receipt["state"], "receipt": str(Path(args.receipt)), "packet_sha256": receipt["packet_sha256"]})
        elif args.command == "verify":
            receipt = verify_reconstruction(load_json(args.packet), args.target)
            atomic_write_json(args.receipt, receipt)
            _print({"state": receipt["state"], "receipt": str(Path(args.receipt)), "packet_sha256": receipt["packet_sha256"]})
        return 0
    except (PacketError, OSError) as exc:
        _print({"state": "HOLD", "error_type": type(exc).__name__, "reason": str(exc)}, stream=sys.stderr)
        return 2
