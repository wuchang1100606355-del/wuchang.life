"""Strict UTF-8 JSON I/O with atomic, no-overwrite writes."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes
from .errors import PacketValidationError, UnsafeTargetError


def load_json(path: str | Path) -> Any:
    source = Path(path)
    try:
        raw = source.read_bytes()
    except OSError as exc:
        raise PacketValidationError(f"cannot read {source}: {exc}") from exc
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PacketValidationError(f"invalid UTF-8 JSON at {source}: {exc}") from exc


def atomic_write_bytes(path: str | Path, data: bytes, *, overwrite: bool = False) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not overwrite:
        raise UnsafeTargetError(f"refusing to overwrite existing target: {target}")
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        if overwrite:
            os.replace(temporary, target)
        else:
            try:
                os.link(temporary, target)
            except FileExistsError as exc:
                raise UnsafeTargetError(f"refusing to overwrite existing target: {target}") from exc
            temporary.unlink()
    finally:
        temporary.unlink(missing_ok=True)
    return target


def atomic_write_json(path: str | Path, value: Any, *, overwrite: bool = False) -> Path:
    return atomic_write_bytes(path, canonical_bytes(value) + b"\n", overwrite=overwrite)
