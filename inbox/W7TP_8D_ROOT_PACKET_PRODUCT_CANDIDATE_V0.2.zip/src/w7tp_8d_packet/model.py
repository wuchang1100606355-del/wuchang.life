"""Strict semantic validation for the candidate 8D state-field packet."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from .canonical import canonical_bytes
from .errors import PacketValidationError

SCHEMA_ID = "w7tp://schemas/8d-root-packet/v0.1-candidate"
CANONICAL_STATUS = "CANDIDATE_NOT_CANONICAL"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
SAFE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}$")
SUPPORTED_OPERATIONS = {"mkdir", "materialize_ref", "render_template", "write_json"}
SUPPORTED_CHECKS = {"path_exists", "file_sha256", "json_pointer_equals"}
HARD_DENIES = {
    "raw_secret_access",
    "plaintext_member_data",
    "overwrite_original",
    "database_write",
    "deploy",
    "restart",
    "reboot",
    "router_write",
    "formal_submission",
    "delete_unverified_local_copy",
}
FORBIDDEN_RAW_KEYS = {
    "password",
    "passwd",
    "secret",
    "client_secret",
    "token",
    "access_token",
    "refresh_token",
    "api_key",
    "authorization",
    "private_key",
    "member_plaintext",
}


def _fail(path: str, message: str) -> None:
    raise PacketValidationError(f"{path}: {message}")


def _mapping(value: Any, path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        _fail(path, "must be an object")
    return value


def _list(value: Any, path: str) -> list[Any]:
    if not isinstance(value, list):
        _fail(path, "must be an array")
    return value


def _string(value: Any, path: str, *, nonempty: bool = True) -> str:
    if not isinstance(value, str):
        _fail(path, "must be a string")
    if nonempty and not value.strip():
        _fail(path, "must not be empty")
    return value


def _identifier(value: Any, path: str) -> str:
    result = _string(value, path)
    if not SAFE_ID.fullmatch(result):
        _fail(path, "contains unsupported identifier characters")
    return result


def _unique(items: Iterable[str], path: str) -> None:
    seen: set[str] = set()
    for item in items:
        if item in seen:
            _fail(path, f"duplicate identifier {item!r}")
        seen.add(item)


def _utc_timestamp(value: Any, path: str, *, optional: bool = False) -> datetime | None:
    if value is None and optional:
        return None
    raw = _string(value, path)
    if not raw.endswith("Z"):
        _fail(path, "must be an RFC 3339 UTC timestamp ending in Z")
    try:
        parsed = datetime.fromisoformat(raw[:-1] + "+00:00")
    except ValueError as exc:
        raise PacketValidationError(f"{path}: invalid timestamp") from exc
    if parsed.tzinfo != timezone.utc:
        _fail(path, "must use UTC")
    return parsed


def _relative_path(value: Any, path: str) -> str:
    raw = _string(value, path)
    parts = raw.replace("\\", "/").split("/")
    if raw.startswith(("/", "\\")) or any(part in {"", ".", ".."} for part in parts):
        _fail(path, "must be a normalized relative path without traversal")
    if ":" in parts[0]:
        _fail(path, "must not be a drive-qualified path")
    return raw


def _reject_raw_sensitive_fields(value: Any, path: str = "$") -> None:
    if isinstance(value, list):
        for index, item in enumerate(value):
            _reject_raw_sensitive_fields(item, f"{path}[{index}]")
        return
    if not isinstance(value, Mapping):
        return
    for key, item in value.items():
        normalized = key.casefold().replace("-", "_")
        if normalized in FORBIDDEN_RAW_KEYS:
            _fail(f"{path}.{key}", "raw secret, token, key, or member plaintext fields are forbidden; use a governed reference")
        _reject_raw_sensitive_fields(item, f"{path}.{key}")


def _validate_d1(d1: Mapping[str, Any]) -> None:
    _identifier(d1.get("identity_id"), "$.d1_identity.identity_id")
    _string(d1.get("founder"), "$.d1_identity.founder")
    _string(d1.get("system_authority"), "$.d1_identity.system_authority")
    _identifier(d1.get("actor_role"), "$.d1_identity.actor_role")
    _identifier(d1.get("trust_domain"), "$.d1_identity.trust_domain")


def _validate_d2(d2: Mapping[str, Any]) -> None:
    _identifier(d2.get("intent_id"), "$.d2_intent.intent_id")
    _string(d2.get("system_name"), "$.d2_intent.system_name")
    _string(d2.get("target_equivalent_state"), "$.d2_intent.target_equivalent_state")
    contract = _list(d2.get("product_contract"), "$.d2_intent.product_contract")
    if not contract:
        _fail("$.d2_intent.product_contract", "must contain at least one invariant")
    for index, item in enumerate(contract):
        _string(item, f"$.d2_intent.product_contract[{index}]")


def _validate_d3(d3: Mapping[str, Any]) -> set[str]:
    _identifier(d3.get("state_id"), "$.d3_state.state_id")
    _string(d3.get("lifecycle"), "$.d3_state.lifecycle")
    components = _list(d3.get("components"), "$.d3_state.components")
    ids: list[str] = []
    dependencies: dict[str, list[str]] = {}
    for index, raw in enumerate(components):
        item = _mapping(raw, f"$.d3_state.components[{index}]")
        component_id = _identifier(item.get("component_id"), f"$.d3_state.components[{index}].component_id")
        ids.append(component_id)
        _string(item.get("role"), f"$.d3_state.components[{index}].role")
        _string(item.get("version"), f"$.d3_state.components[{index}].version")
        _string(item.get("state"), f"$.d3_state.components[{index}].state")
        deps = _list(item.get("dependencies", []), f"$.d3_state.components[{index}].dependencies")
        dependencies[component_id] = [
            _identifier(dep, f"$.d3_state.components[{index}].dependencies") for dep in deps
        ]
    _unique(ids, "$.d3_state.components")
    known = set(ids)
    for component_id, deps in dependencies.items():
        missing = sorted(set(deps) - known)
        if missing:
            _fail(f"$.d3_state.components[{component_id}].dependencies", f"unknown components: {missing}")
        if component_id in deps:
            _fail(f"$.d3_state.components[{component_id}].dependencies", "self-dependency is forbidden")
    return known


def _validate_d4(d4: Mapping[str, Any]) -> set[str]:
    _string(d4.get("coordinate_system"), "$.d4_topology.coordinate_system")
    nodes = _list(d4.get("nodes"), "$.d4_topology.nodes")
    node_ids: list[str] = []
    for index, raw in enumerate(nodes):
        item = _mapping(raw, f"$.d4_topology.nodes[{index}]")
        node_ids.append(_identifier(item.get("node_id"), f"$.d4_topology.nodes[{index}].node_id"))
        _string(item.get("kind"), f"$.d4_topology.nodes[{index}].kind")
        _string(item.get("locator"), f"$.d4_topology.nodes[{index}].locator")
        capabilities = _list(item.get("capabilities", []), f"$.d4_topology.nodes[{index}].capabilities")
        for cap in capabilities:
            _identifier(cap, f"$.d4_topology.nodes[{index}].capabilities")
    _unique(node_ids, "$.d4_topology.nodes")
    known = set(node_ids)
    transitions = _list(d4.get("transitions", []), "$.d4_topology.transitions")
    for index, raw in enumerate(transitions):
        item = _mapping(raw, f"$.d4_topology.transitions[{index}]")
        source = _identifier(item.get("from"), f"$.d4_topology.transitions[{index}].from")
        target = _identifier(item.get("to"), f"$.d4_topology.transitions[{index}].to")
        if source not in known or target not in known:
            _fail(f"$.d4_topology.transitions[{index}]", "transition node is not declared")
        _string(item.get("condition"), f"$.d4_topology.transitions[{index}].condition")
    return known


def _validate_evidence(d5: Mapping[str, Any]) -> set[str]:
    evidence = _list(d5.get("evidence"), "$.d5_resource.evidence")
    ids: list[str] = []
    for index, raw in enumerate(evidence):
        item = _mapping(raw, f"$.d5_resource.evidence[{index}]")
        ids.append(_identifier(item.get("evidence_id"), f"$.d5_resource.evidence[{index}].evidence_id"))
        _string(item.get("kind"), f"$.d5_resource.evidence[{index}].kind")
        _string(item.get("ref"), f"$.d5_resource.evidence[{index}].ref")
        digest = item.get("sha256")
        if digest is not None and (not isinstance(digest, str) or not HEX64.fullmatch(digest)):
            _fail(f"$.d5_resource.evidence[{index}].sha256", "must be lowercase SHA-256")
    _unique(ids, "$.d5_resource.evidence")
    return set(ids)


def _validate_references(d5: Mapping[str, Any]) -> set[str]:
    references = _list(d5.get("references"), "$.d5_resource.references")
    ids: list[str] = []
    for index, raw in enumerate(references):
        item = _mapping(raw, f"$.d5_resource.references[{index}]")
        ids.append(_identifier(item.get("ref_id"), f"$.d5_resource.references[{index}].ref_id"))
        kind = _string(item.get("kind"), f"$.d5_resource.references[{index}].kind")
        if kind not in {"content", "lookup_table", "child_packet", "codebook", "evidence"}:
            _fail(f"$.d5_resource.references[{index}].kind", "unsupported reference kind")
        digest = _string(item.get("sha256"), f"$.d5_resource.references[{index}].sha256")
        if not HEX64.fullmatch(digest):
            _fail(f"$.d5_resource.references[{index}].sha256", "must be lowercase SHA-256")
        size = item.get("size_bytes")
        disclosure = _string(item.get("disclosure", "resolvable"), f"$.d5_resource.references[{index}].disclosure")
        if disclosure == "reference_only":
            if size is not None and (not isinstance(size, int) or isinstance(size, bool) or size < 0):
                _fail(f"$.d5_resource.references[{index}].size_bytes", "must be null or a non-negative integer")
        elif not isinstance(size, int) or isinstance(size, bool) or size < 0:
            _fail(f"$.d5_resource.references[{index}].size_bytes", "must be a non-negative integer")
        _string(item.get("media_type"), f"$.d5_resource.references[{index}].media_type")
        if not isinstance(item.get("required"), bool):
            _fail(f"$.d5_resource.references[{index}].required", "must be boolean")
        if disclosure not in {"resolvable", "reference_only"}:
            _fail(f"$.d5_resource.references[{index}].disclosure", "unsupported disclosure policy")
        if disclosure == "reference_only" and item.get("required"):
            _fail(f"$.d5_resource.references[{index}]", "reference-only resources cannot be receiver-required")
    _unique(ids, "$.d5_resource.references")
    return set(ids)


def _validate_d5(d5: Mapping[str, Any], refs: set[str]) -> None:
    receiver = _mapping(d5.get("receiver"), "$.d5_resource.receiver")
    _identifier(receiver.get("name"), "$.d5_resource.receiver.name")
    _string(receiver.get("version"), "$.d5_resource.receiver.version")
    if receiver.get("model_free") is not True:
        _fail("$.d5_resource.receiver.model_free", "candidate receiver must be model-free")
    prerequisites = _list(d5.get("prerequisites"), "$.d5_resource.prerequisites")
    for index, prerequisite in enumerate(prerequisites):
        _string(prerequisite, f"$.d5_resource.prerequisites[{index}]")
    operations = _list(d5.get("operations"), "$.d5_resource.operations")
    operation_ids: list[str] = []
    for index, raw in enumerate(operations):
        item = _mapping(raw, f"$.d5_resource.operations[{index}]")
        operation_ids.append(_identifier(item.get("operation_id"), f"$.d5_resource.operations[{index}].operation_id"))
        kind = _string(item.get("type"), f"$.d5_resource.operations[{index}].type")
        if kind not in SUPPORTED_OPERATIONS:
            _fail(f"$.d5_resource.operations[{index}].type", f"unsupported operation {kind!r}")
        _relative_path(item.get("target"), f"$.d5_resource.operations[{index}].target")
        if kind in {"materialize_ref", "render_template"}:
            ref_id = _identifier(item.get("ref_id"), f"$.d5_resource.operations[{index}].ref_id")
            if ref_id not in refs:
                _fail(f"$.d5_resource.operations[{index}].ref_id", "reference is not declared")
        if kind == "render_template":
            variables = _mapping(item.get("variables", {}), f"$.d5_resource.operations[{index}].variables")
            for key, value in variables.items():
                _identifier(key, f"$.d5_resource.operations[{index}].variables")
                _string(value, f"$.d5_resource.operations[{index}].variables.{key}", nonempty=False)
        if kind == "write_json":
            if "value" not in item:
                _fail(f"$.d5_resource.operations[{index}].value", "is required")
            canonical_bytes(item["value"])
    _unique(operation_ids, "$.d5_resource.operations")


def _validate_d7(d7: Mapping[str, Any]) -> None:
    mode = _string(d7.get("acceptance_model"), "$.d7_verification.acceptance_model")
    if mode not in {"exact_byte", "equivalent_state"}:
        _fail("$.d7_verification.acceptance_model", "must be exact_byte or equivalent_state")
    _string(d7.get("canonical_ref"), "$.d7_verification.canonical_ref")
    conditions = _list(d7.get("reconstruction_conditions"), "$.d7_verification.reconstruction_conditions")
    if not conditions:
        _fail("$.d7_verification.reconstruction_conditions", "must not be empty")
    for index, condition in enumerate(conditions):
        _string(condition, f"$.d7_verification.reconstruction_conditions[{index}]")
    checks = _list(d7.get("equivalence_checks"), "$.d7_verification.equivalence_checks")
    if not checks:
        _fail("$.d7_verification.equivalence_checks", "must not be empty")
    check_ids: list[str] = []
    for index, raw in enumerate(checks):
        item = _mapping(raw, f"$.d7_verification.equivalence_checks[{index}]")
        check_ids.append(_identifier(item.get("check_id"), f"$.d7_verification.equivalence_checks[{index}].check_id"))
        kind = _string(item.get("type"), f"$.d7_verification.equivalence_checks[{index}].type")
        if kind not in SUPPORTED_CHECKS:
            _fail(f"$.d7_verification.equivalence_checks[{index}].type", "unsupported check")
        _relative_path(item.get("path"), f"$.d7_verification.equivalence_checks[{index}].path")
        if kind == "file_sha256":
            digest = _string(item.get("sha256"), f"$.d7_verification.equivalence_checks[{index}].sha256")
            if not HEX64.fullmatch(digest):
                _fail(f"$.d7_verification.equivalence_checks[{index}].sha256", "must be SHA-256")
        if kind == "json_pointer_equals":
            pointer = _string(item.get("pointer"), f"$.d7_verification.equivalence_checks[{index}].pointer", nonempty=False)
            if pointer and not pointer.startswith("/"):
                _fail(f"$.d7_verification.equivalence_checks[{index}].pointer", "must be empty or start with /")
            if "expected" not in item:
                _fail(f"$.d7_verification.equivalence_checks[{index}].expected", "is required")
            canonical_bytes(item["expected"])
    _unique(check_ids, "$.d7_verification.equivalence_checks")


def _validate_d6(d6: Mapping[str, Any]) -> None:
    _string(d6.get("authority"), "$.d6_governance.authority")
    allowed = _list(d6.get("allow_actions"), "$.d6_governance.allow_actions")
    denied = _list(d6.get("deny_actions"), "$.d6_governance.deny_actions")
    allow_set = {_identifier(item, "$.d6_governance.allow_actions") for item in allowed}
    deny_set = {_identifier(item, "$.d6_governance.deny_actions") for item in denied}
    if "reconstruct_candidate" not in allow_set:
        _fail("$.d6_governance.allow_actions", "reconstruct_candidate must be explicit")
    missing = HARD_DENIES - deny_set
    if missing:
        _fail("$.d6_governance.deny_actions", f"missing hard denials: {sorted(missing)}")
    conflict = allow_set & deny_set
    if conflict:
        _fail("$.d6_governance", f"actions cannot be both allowed and denied: {sorted(conflict)}")
    data_rules = _list(d6.get("data_rules"), "$.d6_governance.data_rules")
    for index, rule in enumerate(data_rules):
        _string(rule, f"$.d6_governance.data_rules[{index}]")


def _validate_d8(d8: Mapping[str, Any]) -> None:
    _identifier(d8.get("packet_id"), "$.d8_envelope.packet_id")
    parent = d8.get("parent_packet_id")
    if parent is not None:
        _identifier(parent, "$.d8_envelope.parent_packet_id")
    created = _utc_timestamp(d8.get("created_at"), "$.d8_envelope.created_at")
    expires = _utc_timestamp(d8.get("expires_at"), "$.d8_envelope.expires_at", optional=True)
    if created and expires and expires <= created:
        _fail("$.d8_envelope.expires_at", "must be later than created_at")
    nonce = _string(d8.get("nonce"), "$.d8_envelope.nonce")
    if len(nonce) < 16:
        _fail("$.d8_envelope.nonce", "must contain at least 16 characters")
    protocol = _mapping(d8.get("protocol"), "$.d8_envelope.protocol")
    if protocol.get("name") != "W7TP-8D-GT":
        _fail("$.d8_envelope.protocol.name", "must be W7TP-8D-GT")
    _string(protocol.get("version"), "$.d8_envelope.protocol.version")
    integrity = _mapping(d8.get("integrity"), "$.d8_envelope.integrity")
    if integrity.get("algorithm") != "sha256":
        _fail("$.d8_envelope.integrity.algorithm", "must be sha256")
    digest = integrity.get("packet_sha256")
    if not isinstance(digest, str) or (digest and not HEX64.fullmatch(digest)):
        _fail("$.d8_envelope.integrity.packet_sha256", "must be empty while building or lowercase SHA-256")
    verification = _mapping(d8.get("verification"), "$.d8_envelope.verification")
    checks = _list(verification.get("required_checks"), "$.d8_envelope.verification.required_checks")
    required = {"envelope_hash", "references", "reconstruction", "equivalence", "governance"}
    if not required.issubset(set(checks)):
        _fail("$.d8_envelope.verification.required_checks", f"must include {sorted(required)}")
    governance = _mapping(d8.get("governance"), "$.d8_envelope.governance")
    if governance.get("status") != CANONICAL_STATUS:
        _fail("$.d8_envelope.governance.status", f"must be {CANONICAL_STATUS}")
    receipt_ref = governance.get("total_field_receipt_ref")
    if receipt_ref is not None:
        _string(receipt_ref, "$.d8_envelope.governance.total_field_receipt_ref")


def validate_packet(packet: Any, *, allow_unsealed: bool = False) -> dict[str, Any]:
    root = _mapping(packet, "$")
    _reject_raw_sensitive_fields(root)
    required = {
        "schema",
        "canonical_status",
        "d1_identity",
        "d2_intent",
        "d3_state",
        "d4_topology",
        "d5_resource",
        "d6_governance",
        "d7_verification",
        "d8_envelope",
    }
    missing = required - set(root)
    extra = set(root) - required
    if missing or extra:
        _fail("$", f"top-level keys mismatch; missing={sorted(missing)} extra={sorted(extra)}")
    if root["schema"] != SCHEMA_ID:
        _fail("$.schema", f"must be {SCHEMA_ID}")
    if root["canonical_status"] != CANONICAL_STATUS:
        _fail("$.canonical_status", f"must be {CANONICAL_STATUS}")
    _validate_d1(_mapping(root["d1_identity"], "$.d1_identity"))
    _validate_d2(_mapping(root["d2_intent"], "$.d2_intent"))
    _validate_d3(_mapping(root["d3_state"], "$.d3_state"))
    _validate_d4(_mapping(root["d4_topology"], "$.d4_topology"))
    d5 = _mapping(root["d5_resource"], "$.d5_resource")
    _validate_evidence(d5)
    refs = _validate_references(d5)
    _validate_d5(d5, refs)
    _validate_d6(_mapping(root["d6_governance"], "$.d6_governance"))
    _validate_d7(_mapping(root["d7_verification"], "$.d7_verification"))
    d8 = _mapping(root["d8_envelope"], "$.d8_envelope")
    _validate_d8(d8)
    if not allow_unsealed and not d8["integrity"]["packet_sha256"]:
        _fail("$.d8_envelope.integrity.packet_sha256", "packet is not sealed")
    canonical_bytes(root)
    return dict(root)
