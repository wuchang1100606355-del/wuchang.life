"""Crash-safe, file-backed nonce replay guard for a single receiver domain."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

from .errors import GovernanceDenied


class ReplayReservation:
    def __init__(self, marker: Path, payload: bytes):
        self.marker = marker
        self.payload = payload
        self.committed = False

    def __enter__(self) -> "ReplayReservation":
        self.marker.parent.mkdir(parents=True, exist_ok=True)
        try:
            descriptor = os.open(self.marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError as exc:
            raise GovernanceDenied("packet nonce has already been reserved or consumed") from exc
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(self.payload)
            handle.flush()
            os.fsync(handle.fileno())
        return self

    def commit(self) -> None:
        self.committed = True

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        if exc_type is not None or not self.committed:
            self.marker.unlink(missing_ok=True)


class ReplayGuard:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        if self.root.is_symlink():
            raise GovernanceDenied(f"replay ledger root must not be a symlink: {self.root}")

    def reserve(self, packet_id: str, nonce: str, packet_sha256: str) -> ReplayReservation:
        key = hashlib.sha256(f"{packet_id}\x00{nonce}".encode("utf-8")).hexdigest()
        marker = self.root / key[:2] / key
        return ReplayReservation(marker, f"{packet_sha256}\n".encode("ascii"))
