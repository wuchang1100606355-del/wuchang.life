"""Deterministic serialization and envelope integrity.

Floats are deliberately rejected. W7TP candidate packets use deterministic,
integer/string/lookup state so different receivers hash the same logical body.
"""

from __future__ import annotations

import copy
import hashlib
import json
import unicodedata
from typing import Any

from .errors import IntegrityError, PacketValidationError


def _normalize(value: Any, path: str = "$") -> Any:
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        raise PacketValidationError(f"{path}: floating-point values are forbidden")
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, list):
        return [_normalize(item, f"{path}[{index}]") for index, item in enumerate(value)]
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise PacketValidationError(f"{path}: object keys must be strings")
            clean_key = unicodedata.normalize("NFC", key)
            if clean_key in normalized:
                raise PacketValidationError(f"{path}: duplicate key after Unicode normalization")
            normalized[clean_key] = _normalize(item, f"{path}.{clean_key}")
        return normalized
    raise PacketValidationError(f"{path}: unsupported value type {type(value).__name__}")


def canonical_bytes(value: Any) -> bytes:
    normalized = _normalize(value)
    return json.dumps(
        normalized,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def packet_hash_body(packet: dict[str, Any]) -> dict[str, Any]:
    body = copy.deepcopy(packet)
    try:
        body["d8_envelope"]["integrity"]["packet_sha256"] = ""
    except (KeyError, TypeError) as exc:
        raise PacketValidationError("$.d8_envelope.integrity.packet_sha256 is required") from exc
    return body


def calculate_packet_sha256(packet: dict[str, Any]) -> str:
    return sha256_bytes(canonical_bytes(packet_hash_body(packet)))


def verify_packet_sha256(packet: dict[str, Any]) -> str:
    expected = packet.get("d8_envelope", {}).get("integrity", {}).get("packet_sha256")
    actual = calculate_packet_sha256(packet)
    if expected != actual:
        raise IntegrityError(f"packet SHA-256 mismatch: expected={expected!r} actual={actual}")
    return actual

