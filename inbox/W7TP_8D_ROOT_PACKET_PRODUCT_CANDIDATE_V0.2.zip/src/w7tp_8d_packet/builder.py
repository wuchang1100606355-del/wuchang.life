"""Packet construction and sealing."""

from __future__ import annotations

import copy
from typing import Any, Mapping

from .canonical import calculate_packet_sha256, verify_packet_sha256
from .model import CANONICAL_STATUS, SCHEMA_ID, validate_packet


def seal_packet(packet: Mapping[str, Any]) -> dict[str, Any]:
    candidate = copy.deepcopy(dict(packet))
    candidate["d8_envelope"]["integrity"]["packet_sha256"] = ""
    validate_packet(candidate, allow_unsealed=True)
    candidate["d8_envelope"]["integrity"]["packet_sha256"] = calculate_packet_sha256(candidate)
    validate_packet(candidate)
    verify_packet_sha256(candidate)
    return candidate


def build_packet(spec: Mapping[str, Any]) -> dict[str, Any]:
    """Build a sealed packet from a full eight-field specification.

    The builder supplies only candidate identity defaults. It never invents
    intent, coordinates, references, reconstruction rules, or governance.
    """

    packet = copy.deepcopy(dict(spec))
    packet.setdefault("schema", SCHEMA_ID)
    packet.setdefault("canonical_status", CANONICAL_STATUS)
    envelope = packet.get("d8_envelope")
    if isinstance(envelope, dict):
        integrity = envelope.setdefault("integrity", {})
        if isinstance(integrity, dict):
            integrity.setdefault("algorithm", "sha256")
            integrity["packet_sha256"] = ""
    return seal_packet(packet)

