"""Deterministic, model-free, no-overwrite packet receiver."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .canonical import canonical_bytes, sha256_bytes, verify_packet_sha256
from .errors import GovernanceDenied, IntegrityError, UnsafeTargetError
from .io import atomic_write_bytes
from .model import validate_packet
from .replay import ReplayGuard
from .store import ContentStore
from .verifier import preflight_packet, verify_reconstruction

TOKEN = re.compile(r"\{\{([A-Za-z0-9][A-Za-z0-9._:/-]{0,255})\}\}")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _safe_target(root: Path, relative: str) -> Path:
    root_resolved = root.resolve()
    target = (root_resolved / relative).resolve()
    if target != root_resolved and root_resolved not in target.parents:
        raise UnsafeTargetError(f"operation target escapes receiver root: {relative}")
    return target


def _prepare_root(target_root: str | Path) -> Path:
    root = Path(target_root)
    if root.is_symlink():
        raise UnsafeTargetError(f"receiver target must not be a symlink: {root}")
    if root.exists():
        if not root.is_dir():
            raise UnsafeTargetError(f"receiver target is not a directory: {root}")
        if any(root.iterdir()):
            raise UnsafeTargetError(f"receiver target must be new or empty: {root}")
    else:
        root.mkdir(parents=True)
    return root


def _render_template(data: bytes, variables: dict[str, str]) -> bytes:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise IntegrityError("template reference is not UTF-8") from exc
    tokens = set(TOKEN.findall(text))
    missing = tokens - set(variables)
    extra = set(variables) - tokens
    if missing or extra:
        raise IntegrityError(f"template variable mismatch: missing={sorted(missing)} extra={sorted(extra)}")
    return TOKEN.sub(lambda match: variables[match.group(1)], text).encode("utf-8")


def reconstruct_packet(
    packet: dict[str, Any],
    store: ContentStore,
    target_root: str | Path,
    replay_guard: ReplayGuard,
) -> dict[str, Any]:
    validate_packet(packet)
    packet_digest = verify_packet_sha256(packet)
    allowed = set(packet["d6_governance"]["allow_actions"])
    if "reconstruct_candidate" not in allowed:
        raise GovernanceDenied("packet does not authorize candidate reconstruction")
    preflight = preflight_packet(packet, store)
    with replay_guard.reserve(
        packet["d8_envelope"]["packet_id"], packet["d8_envelope"]["nonce"], packet_digest
    ) as reservation:
        root = _prepare_root(target_root)
        references = {
            item["ref_id"]: item for item in packet["d5_resource"]["references"]
        }
        outputs: list[dict[str, Any]] = []
        created: list[Path] = []
        try:
            for operation in packet["d5_resource"]["operations"]:
                target = _safe_target(root, operation["target"])
                if target.exists():
                    raise UnsafeTargetError(f"operation would overwrite target: {operation['target']}")
                kind = operation["type"]
                if kind == "mkdir":
                    target.mkdir(parents=True, exist_ok=False)
                    created.append(target)
                    outputs.append(
                        {"operation_id": operation["operation_id"], "target": operation["target"], "kind": "directory"}
                    )
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                if kind == "materialize_ref":
                    data = store.resolve(references[operation["ref_id"]])
                elif kind == "render_template":
                    data = _render_template(
                        store.resolve(references[operation["ref_id"]]), operation.get("variables", {})
                    )
                elif kind == "write_json":
                    data = canonical_bytes(operation["value"]) + b"\n"
                else:  # guarded by validate_packet
                    raise IntegrityError(f"unsupported reconstruction operation: {kind}")
                atomic_write_bytes(target, data)
                created.append(target)
                outputs.append(
                    {
                        "operation_id": operation["operation_id"],
                        "target": operation["target"],
                        "kind": "file",
                        "size_bytes": len(data),
                        "sha256": sha256_bytes(data),
                    }
                )
            verification = verify_reconstruction(packet, root)
        except Exception:
            # Roll back only paths created by this call; originals are never touched.
            for path in reversed(created):
                if path.is_file():
                    path.unlink(missing_ok=True)
                elif path.is_dir():
                    try:
                        path.rmdir()
                    except OSError:
                        pass
            # Remove empty parents below root, preserving the requested root itself.
            for parent in sorted({p.parent for p in created}, key=lambda p: len(p.parts), reverse=True):
                if parent != root:
                    try:
                        parent.rmdir()
                    except OSError:
                        pass
            raise
        reservation.commit()
    return {
        "state": "PASS_EXECUTED_AND_VERIFIED",
        "packet_id": packet["d8_envelope"]["packet_id"],
        "packet_sha256": packet_digest,
        "receiver": packet["d5_resource"]["receiver"],
        "target_root": str(root.resolve()),
        "completed_at": _now(),
        "preflight": preflight,
        "outputs": outputs,
        "verification": verification,
        "governance": {
            "canonical_status": packet["canonical_status"],
            "total_field_receipt_ref": packet["d8_envelope"]["governance"]["total_field_receipt_ref"],
        },
    }
