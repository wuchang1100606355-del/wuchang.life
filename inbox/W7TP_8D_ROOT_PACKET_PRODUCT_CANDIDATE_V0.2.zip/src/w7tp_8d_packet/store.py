"""Local content-addressed resource store used by the model-free receiver."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any

from .canonical import sha256_bytes
from .errors import IntegrityError, PreconditionMissing


class ContentStore:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        if self.root.is_symlink():
            raise IntegrityError(f"content store root must not be a symlink: {self.root}")

    def _path(self, digest: str) -> Path:
        return self.root / "sha256" / digest[:2] / digest

    def put_bytes(
        self,
        data: bytes,
        *,
        ref_id: str,
        kind: str = "content",
        media_type: str = "application/octet-stream",
        required: bool = True,
        disclosure: str = "resolvable",
    ) -> dict[str, Any]:
        digest = sha256_bytes(data)
        target = self._path(digest)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            existing = target.read_bytes()
            if sha256_bytes(existing) != digest:
                raise IntegrityError(f"content store collision or corruption at {target}")
        else:
            descriptor, temporary_name = tempfile.mkstemp(prefix=".w7tp-", dir=target.parent)
            temporary = Path(temporary_name)
            try:
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
                try:
                    os.link(temporary, target)
                except FileExistsError:
                    existing = target.read_bytes()
                    if sha256_bytes(existing) != digest or len(existing) != len(data):
                        raise IntegrityError(f"content store race mismatch at {target}")
            finally:
                temporary.unlink(missing_ok=True)
        return {
            "ref_id": ref_id,
            "kind": kind,
            "sha256": digest,
            "size_bytes": len(data),
            "media_type": media_type,
            "required": required,
            "disclosure": disclosure,
        }

    def put_file(self, path: str | Path, *, ref_id: str, media_type: str) -> dict[str, Any]:
        return self.put_bytes(Path(path).read_bytes(), ref_id=ref_id, media_type=media_type)

    def has(self, reference: dict[str, Any]) -> bool:
        if reference.get("disclosure", "resolvable") == "reference_only":
            return True
        path = self._path(reference["sha256"])
        if not path.is_file():
            return False
        data = path.read_bytes()
        return len(data) == reference["size_bytes"] and sha256_bytes(data) == reference["sha256"]

    def resolve(self, reference: dict[str, Any]) -> bytes:
        if reference.get("disclosure", "resolvable") == "reference_only":
            raise PreconditionMissing(f"reference {reference['ref_id']} is protected reference-only material")
        path = self._path(reference["sha256"])
        if not path.is_file():
            raise PreconditionMissing(f"missing reference {reference['ref_id']} ({reference['sha256']})")
        data = path.read_bytes()
        actual = sha256_bytes(data)
        if actual != reference["sha256"] or len(data) != reference["size_bytes"]:
            raise IntegrityError(
                f"reference {reference['ref_id']} mismatch: digest={actual} size={len(data)}"
            )
        return data
