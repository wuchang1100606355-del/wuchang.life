from __future__ import annotations

import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from w7tp_8d_packet.builder import build_packet, seal_packet
from w7tp_8d_packet.canonical import verify_packet_sha256
from w7tp_8d_packet.errors import (
    GovernanceDenied,
    IntegrityError,
    PacketValidationError,
    PreconditionMissing,
    UnsafeTargetError,
    VerificationError,
)
from w7tp_8d_packet.model import validate_packet
from w7tp_8d_packet.receiver import reconstruct_packet
from w7tp_8d_packet.replay import ReplayGuard
from w7tp_8d_packet.store import ContentStore
from w7tp_8d_packet.verifier import preflight_packet, verify_reconstruction

SPEC = importlib.util.spec_from_file_location("build_demo", PROJECT_ROOT / "examples" / "build_demo.py")
assert SPEC and SPEC.loader
DEMO = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DEMO)


class PacketTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.store = ContentStore(self.root / "store")
        self.packet = build_packet(DEMO.make_demo_spec(self.store))

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_packet_build_and_integrity(self) -> None:
        validate_packet(self.packet)
        self.assertEqual(
            verify_packet_sha256(self.packet), self.packet["d8_envelope"]["integrity"]["packet_sha256"]
        )

    def test_tamper_is_rejected(self) -> None:
        tampered = copy.deepcopy(self.packet)
        tampered["d2_intent"]["system_name"] = "tampered"
        with self.assertRaises(IntegrityError):
            verify_packet_sha256(tampered)

    def test_float_is_rejected(self) -> None:
        spec = DEMO.make_demo_spec(self.store)
        spec["d5_resource"]["operations"][-1]["value"]["forbidden_float"] = 1.5
        with self.assertRaises(PacketValidationError):
            build_packet(spec)

    def test_path_traversal_is_rejected(self) -> None:
        spec = DEMO.make_demo_spec(self.store)
        spec["d5_resource"]["operations"][0]["target"] = "../escape"
        with self.assertRaises(PacketValidationError):
            build_packet(spec)

    def test_raw_secret_field_is_rejected(self) -> None:
        spec = DEMO.make_demo_spec(self.store)
        spec["d5_resource"]["password"] = "must-not-enter-packet"
        with self.assertRaises(PacketValidationError):
            build_packet(spec)

    def test_missing_required_reference_holds(self) -> None:
        empty_store = ContentStore(self.root / "empty-store")
        with self.assertRaises(PreconditionMissing):
            preflight_packet(self.packet, empty_store)

    def test_reconstruction_and_equivalent_state_verification(self) -> None:
        receipt = reconstruct_packet(
            self.packet, self.store, self.root / "receiver", ReplayGuard(self.root / "replay")
        )
        self.assertEqual(receipt["state"], "PASS_EXECUTED_AND_VERIFIED")
        self.assertEqual(receipt["verification"]["state"], "PASS_EQUIVALENT_STATE_VERIFIED")
        registry = json.loads((self.root / "receiver/system-design/component-registry.json").read_text())
        self.assertFalse(registry["member_plaintext_embedded"])

    def test_replay_is_rejected(self) -> None:
        guard = ReplayGuard(self.root / "replay")
        reconstruct_packet(self.packet, self.store, self.root / "receiver-a", guard)
        with self.assertRaises(GovernanceDenied):
            reconstruct_packet(self.packet, self.store, self.root / "receiver-b", guard)

    def test_nonempty_target_is_rejected_without_overwrite(self) -> None:
        target = self.root / "receiver"
        target.mkdir()
        original = target / "original.txt"
        original.write_text("preserve", encoding="utf-8")
        with self.assertRaises(UnsafeTargetError):
            reconstruct_packet(self.packet, self.store, target, ReplayGuard(self.root / "replay"))
        self.assertEqual(original.read_text(encoding="utf-8"), "preserve")

    def test_expired_packet_holds(self) -> None:
        expired = copy.deepcopy(self.packet)
        created = datetime.now(timezone.utc) - timedelta(minutes=2)
        expired_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        expired["d8_envelope"]["created_at"] = created.isoformat(timespec="seconds").replace("+00:00", "Z")
        expired["d8_envelope"]["expires_at"] = expired_at.isoformat(timespec="seconds").replace("+00:00", "Z")
        expired = seal_packet(expired)
        with self.assertRaises(VerificationError):
            preflight_packet(expired, self.store)

    def test_modified_receiver_output_fails_verification(self) -> None:
        reconstruct_packet(self.packet, self.store, self.root / "receiver", ReplayGuard(self.root / "replay"))
        readme = self.root / "receiver/system-design/README.md"
        readme.write_text("tampered", encoding="utf-8")
        with self.assertRaises(VerificationError):
            verify_reconstruction(self.packet, self.root / "receiver")


if __name__ == "__main__":
    unittest.main()
