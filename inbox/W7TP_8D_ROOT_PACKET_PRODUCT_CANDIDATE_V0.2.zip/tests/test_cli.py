from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from w7tp_8d_packet.cli import main
from w7tp_8d_packet.io import atomic_write_json
from w7tp_8d_packet.store import ContentStore

SPEC = importlib.util.spec_from_file_location("build_demo_cli", PROJECT_ROOT / "examples" / "build_demo.py")
assert SPEC and SPEC.loader
DEMO = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DEMO)


class CliTestCase(unittest.TestCase):
    def test_full_cli_flow(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store_path = root / "store"
            spec_path = atomic_write_json(root / "spec.json", DEMO.make_demo_spec(ContentStore(store_path)))
            packet_path = root / "packet.json"
            self.assertEqual(main(["build", "--spec", str(spec_path), "--output", str(packet_path)]), 0)
            self.assertEqual(main(["validate", str(packet_path)]), 0)
            self.assertEqual(main(["preflight", str(packet_path), "--store", str(store_path)]), 0)
            receipt_path = root / "receipt.json"
            self.assertEqual(
                main(
                    [
                        "reconstruct",
                        str(packet_path),
                        "--store",
                        str(store_path),
                        "--target",
                        str(root / "receiver"),
                        "--replay-dir",
                        str(root / "replay"),
                        "--receipt",
                        str(receipt_path),
                    ]
                ),
                0,
            )
            self.assertEqual(json.loads(receipt_path.read_text())["state"], "PASS_EXECUTED_AND_VERIFIED")


if __name__ == "__main__":
    unittest.main()
