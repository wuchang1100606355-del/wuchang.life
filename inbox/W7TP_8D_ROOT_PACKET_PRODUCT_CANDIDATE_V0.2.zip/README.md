# W7TP 8D 根封包產品核心候選版

`STATE=CANDIDATE_NOT_CANONICAL`

這是一個可執行、零第三方執行期相依的 Python 產品核心候選版。它把單一 8D 根封包實作為：

- `D1身分 → D2意圖 → D3狀態 → D4拓樸 → D5資源 → D6治理 → D7驗證 → D8封套` 八個互動狀態場，不是八個裝飾欄位；
- 內容定址引用、查表與子封包關係；
- 封包自帶重構條件、接收器契約與驗證程序；
- 精確位元組或等價狀態兩種明確驗收模型；
- 治理閘門、封套完整性與可貼回執；
- 安全接收器只在全新目標目錄重構，不部署、不重啟、不寫資料庫。

它不是壓縮、備份、雲端密文同步、下載解密或完整檔案搬運的改名。

## 最短執行

```bash
python3 -m unittest discover -s tests -v
python3 examples/build_demo.py --work-root ./demo-run
```

示範會建立內容定址儲存、生成並封印一個 W7TP 8D 根封包、在獨立接收端重構系統設計投影，最後依封包攜帶的驗證契約產生回執。

Founder 請求 `W7TP_PRODUCT_SYSTEM_ROOT_PACKET_20260722T204105Z` 的實際候選產生器：

```bash
PYTHONPATH=src python3 examples/build_product_system_root.py \
  --request inputs/W7TP_PRODUCT_SYSTEM_ROOT_PACKET_20260722T204105Z_REQUEST.json \
  --output-root ./product-root-run
```

此流程直接產生 `W7TP_PRODUCT_SYSTEM_ROOT_PACKET.json`、執行本地隔離重構並產生 `TOTAL_FIELD_RECEIPT_CANDIDATE.json`。

## 命令列

```bash
PYTHONPATH=src python3 -m w7tp_8d_packet build --spec spec.json --output packet.json
PYTHONPATH=src python3 -m w7tp_8d_packet validate packet.json
PYTHONPATH=src python3 -m w7tp_8d_packet preflight packet.json --store ./store
PYTHONPATH=src python3 -m w7tp_8d_packet reconstruct packet.json --store ./store --target ./receiver --receipt receipt.json
PYTHONPATH=src python3 -m w7tp_8d_packet verify packet.json --target ./receiver --receipt verify.json
```

## 正典接合邊界

此候選版鎖定生成式傳輸的最低不變條件，但尚未讀取或修改正式總場正典：

`docs/total_field/W7TP_8D_MULTIPURPOSE_GENERATIVE_TRANSMISSION_PACKET_CANONICAL_V2.md`

正式接合時必須由現行正典欄位映射、總場 receiver receipt 與治理決定取代候選命名；不得把本專案自行宣告為正典。

本候選與總場路由輸出的 `CODE_GENERATION / code.generation.patch.v1` 一致：雲端結果只能是候選，必須回到本地重構及驗證後才能進入下一個治理狀態。
