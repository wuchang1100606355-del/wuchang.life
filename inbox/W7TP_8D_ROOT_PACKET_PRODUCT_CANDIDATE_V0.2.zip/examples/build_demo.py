#!/usr/bin/env python3
"""Build, reconstruct, and verify one mixed software/state-field root packet."""

from __future__ import annotations

import argparse
import json
import secrets
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from w7tp_8d_packet.builder import build_packet  # noqa: E402
from w7tp_8d_packet.canonical import canonical_bytes, sha256_bytes  # noqa: E402
from w7tp_8d_packet.io import atomic_write_json  # noqa: E402
from w7tp_8d_packet.receiver import reconstruct_packet  # noqa: E402
from w7tp_8d_packet.replay import ReplayGuard  # noqa: E402
from w7tp_8d_packet.store import ContentStore  # noqa: E402


HARD_DENIES = [
    "raw_secret_access",
    "plaintext_member_data",
    "overwrite_original",
    "database_write",
    "deploy",
    "restart",
    "reboot",
    "router_write",
    "formal_submission",
    "delete_unverified_local_copy",
]


def _utc(value: datetime) -> str:
    return value.isoformat(timespec="seconds").replace("+00:00", "Z")


def make_demo_spec(store: ContentStore, now: datetime | None = None) -> dict:
    current = now or datetime.now(timezone.utc)
    template = (
        "# {{SYSTEM_NAME}}\n\n"
        "封包狀態：{{PACKET_STATUS}}\n\n"
        "本投影由單一 8D 根封包的引用、重構條件與驗證契約生成。\n"
    ).encode("utf-8")
    template_ref = store.put_bytes(
        template,
        ref_id="ref:system-readme-template",
        kind="lookup_table",
        media_type="text/markdown; charset=utf-8",
    )
    rendered_readme = (
        "# 五常總場產品系統\n\n"
        "封包狀態：CANDIDATE_NOT_CANONICAL\n\n"
        "本投影由單一 8D 根封包的引用、重構條件與驗證契約生成。\n"
    ).encode("utf-8")
    registry = {
        "system": "wuchang-total-field",
        "root_packet_role": "single-governed-system-entry",
        "components": [
            "total-field",
            "xiaoj-intent-field",
            "odoo",
            "pos",
            "community-membership",
            "committee-governance",
        ],
        "member_plaintext_embedded": False,
        "secrets_embedded": False,
    }
    registry_bytes = canonical_bytes(registry) + b"\n"
    return {
        "d1_identity": {
            "identity_id": "identity:founder:wuchang-root-packet",
            "founder": "江政隆（CHIANG Cheng-Lung）",
            "system_authority": "W7TP Founder and accountable natural person",
            "actor_role": "founder",
            "trust_domain": "wuchang-total-field",
        },
        "d2_intent": {
            "intent_id": "intent:wuchang-product-system-root",
            "system_name": "五常總場產品系統",
            "target_equivalent_state": "在合格 Linux 接收端生成可驗證的系統設計投影",
            "product_contract": [
                "單一根封套統攝所有子狀態場",
                "缺件只能依內容定址引用補齊",
                "接收端必須執行封包攜帶的等價狀態驗證",
                "不得攜帶會員明文或原始祕密",
            ],
        },
        "d3_state": {
            "state_id": "state:product-candidate-v0.1",
            "lifecycle": "isolated-product-candidate",
            "components": [
                {"component_id": "total-field", "role": "governance-and-verification", "version": "candidate", "state": "referenced", "dependencies": []},
                {"component_id": "xiaoj-intent-field", "role": "intent-authority", "version": "candidate", "state": "referenced", "dependencies": ["total-field"]},
                {"component_id": "odoo", "role": "business-system", "version": "18", "state": "referenced-not-deployed", "dependencies": ["total-field", "xiaoj-intent-field"]},
                {"component_id": "pos", "role": "store-transaction-projection", "version": "candidate", "state": "referenced-not-deployed", "dependencies": ["odoo"]},
                {"component_id": "community-membership", "role": "member-sovereignty", "version": "candidate", "state": "reference-only", "dependencies": ["total-field", "odoo"]},
                {"component_id": "committee-governance", "role": "association-governance", "version": "candidate", "state": "reference-only", "dependencies": ["total-field", "odoo"]},
            ],
        },
        "d4_topology": {
            "coordinate_system": "W7TP-D3-logical-node-and-transition-v1",
            "nodes": [
                {"node_id": "founder-client", "kind": "human-intent-entry", "locator": "logical://founder/client", "capabilities": ["submit_intent"]},
                {"node_id": "intent-field", "kind": "intent-authority", "locator": "logical://xiaoj/intent-field", "capabilities": ["normalize_intent", "route_candidate"]},
                {"node_id": "total-field-node", "kind": "governance", "locator": "logical://total-field", "capabilities": ["verify", "govern"]},
                {"node_id": "receiver-linux", "kind": "receiver", "locator": "logical://receiver/linux", "capabilities": ["lookup", "reconstruct", "verify"]},
            ],
            "transitions": [
                {"from": "founder-client", "to": "intent-field", "condition": "Founder 意圖進入受限解析"},
                {"from": "intent-field", "to": "total-field-node", "condition": "候選封包提交治理"},
                {"from": "total-field-node", "to": "receiver-linux", "condition": "授權且前置條件完整"},
            ],
        },
        "d5_resource": {
            "evidence": [
                {
                    "evidence_id": "evidence:canonical-locator",
                    "kind": "canonical-reference",
                    "ref": "docs/total_field/W7TP_8D_MULTIPURPOSE_GENERATIVE_TRANSMISSION_PACKET_CANONICAL_V2.md",
                    "sha256": "a5281f229ced0943072cce373125be16f0d361b9352a71094ad5450a6022d5d0",
                },
                {
                    "evidence_id": "evidence:candidate-source",
                    "kind": "source-tree",
                    "ref": "w7tp_8d_root_packet_candidate",
                },
            ],
            "receiver": {"name": "w7tp-python-receiver", "version": "0.1.0", "model_free": True},
            "prerequisites": [
                "Python 3.11 或更新版本",
                "封包宣告的必要內容定址引用",
                "獨立且為空的接收目標",
                "接收端防重放紀錄",
            ],
            "operations": [
                {"operation_id": "op:design-directory", "type": "mkdir", "target": "system-design"},
                {
                    "operation_id": "op:render-readme",
                    "type": "render_template",
                    "target": "system-design/README.md",
                    "ref_id": "ref:system-readme-template",
                    "variables": {"SYSTEM_NAME": "五常總場產品系統", "PACKET_STATUS": "CANDIDATE_NOT_CANONICAL"},
                },
                {
                    "operation_id": "op:write-registry",
                    "type": "write_json",
                    "target": "system-design/component-registry.json",
                    "value": registry,
                },
            ],
            "references": [template_ref],
        },
        "d6_governance": {
            "authority": "Founder candidate; Total Field promotion required",
            "allow_actions": ["reconstruct_candidate", "verify_candidate"],
            "deny_actions": HARD_DENIES,
            "data_rules": [
                "會員資料只能以授權引用表達",
                "祕密只能由接收環境的外部提供者解析，不得寫入封包",
                "H64-TD 僅允許 reference-only",
            ],
        },
        "d7_verification": {
            "acceptance_model": "equivalent_state",
            "canonical_ref": "W7TP_8D_MULTIPURPOSE_GENERATIVE_TRANSMISSION_PACKET_CANONICAL_V2@a5281f22",
            "reconstruction_conditions": [
                "接收端依 SHA-256 解析所有 required 引用",
                "所有輸出只能寫入新的接收根目錄",
                "模板只接受封包內明列變數且不得讀取環境祕密",
                "完成後執行本封包 equivalence_checks",
            ],
            "equivalence_checks": [
                {"check_id": "check:design-directory", "type": "path_exists", "path": "system-design"},
                {"check_id": "check:readme-bytes", "type": "file_sha256", "path": "system-design/README.md", "sha256": sha256_bytes(rendered_readme)},
                {"check_id": "check:registry-bytes", "type": "file_sha256", "path": "system-design/component-registry.json", "sha256": sha256_bytes(registry_bytes)},
                {"check_id": "check:no-member-plaintext", "type": "json_pointer_equals", "path": "system-design/component-registry.json", "pointer": "/member_plaintext_embedded", "expected": False},
            ],
        },
        "d8_envelope": {
            "packet_id": f"packet:wuchang-system:{uuid.uuid4()}",
            "parent_packet_id": None,
            "created_at": _utc(current),
            "expires_at": _utc(current + timedelta(hours=1)),
            "nonce": secrets.token_hex(24),
            "protocol": {"name": "W7TP-8D-GT", "version": "0.1-candidate"},
            "integrity": {"algorithm": "sha256", "packet_sha256": ""},
            "verification": {
                "required_checks": ["envelope_hash", "references", "reconstruction", "equivalence", "governance"]
            },
            "governance": {"status": "CANDIDATE_NOT_CANONICAL", "total_field_receipt_ref": None},
        },
    }


def run_demo(work_root: Path) -> dict:
    if work_root.exists() and any(work_root.iterdir()):
        raise SystemExit(f"STATE=HOLD_TARGET_NOT_EMPTY path={work_root}")
    work_root.mkdir(parents=True, exist_ok=True)
    store = ContentStore(work_root / "store")
    packet = build_packet(make_demo_spec(store))
    packet_path = atomic_write_json(work_root / "packet.json", packet)
    receipt = reconstruct_packet(
        packet,
        store,
        work_root / "receiver",
        ReplayGuard(work_root / "replay-ledger"),
    )
    receipt_path = atomic_write_json(work_root / "receipt.json", receipt)
    manifest = {
        "state": receipt["state"],
        "packet": {"path": packet_path.name, "sha256": sha256_bytes(packet_path.read_bytes())},
        "receipt": {"path": receipt_path.name, "sha256": sha256_bytes(receipt_path.read_bytes())},
        "packet_body_sha256": packet["d8_envelope"]["integrity"]["packet_sha256"],
        "receiver_output_count": len(receipt["outputs"]),
        "canonical_status": packet["canonical_status"],
    }
    atomic_write_json(work_root / "manifest.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run_demo(args.work_root), ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
