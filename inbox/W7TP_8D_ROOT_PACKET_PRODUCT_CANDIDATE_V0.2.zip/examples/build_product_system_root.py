#!/usr/bin/env python3
"""Generate the actual cloud candidate requested by the Founder handoff packet."""

from __future__ import annotations

import argparse
import json
import secrets
import sys
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from w7tp_8d_packet.builder import build_packet  # noqa: E402
from w7tp_8d_packet.canonical import canonical_bytes, sha256_bytes  # noqa: E402
from w7tp_8d_packet.io import atomic_write_json, load_json  # noqa: E402
from w7tp_8d_packet.receiver import reconstruct_packet  # noqa: E402
from w7tp_8d_packet.replay import ReplayGuard  # noqa: E402
from w7tp_8d_packet.store import ContentStore  # noqa: E402

RUN_ID = "W7TP_PRODUCT_SYSTEM_ROOT_PACKET_20260722T204105Z"
CANONICAL_SHA256 = "a5281f229ced0943072cce373125be16f0d361b9352a71094ad5450a6022d5d0"
NLP_COMMIT = "b4269bbd376924696a9cc568bb2dffcf0cb90019"
HARD_DENIES = [
    "raw_secret_access",
    "plaintext_member_data",
    "overwrite_original",
    "database_write",
    "deploy",
    "restart",
    "reboot",
    "router_write",
    "formal_submission",
    "delete_unverified_local_copy",
]


def _utc(value: datetime) -> str:
    return value.isoformat(timespec="seconds").replace("+00:00", "Z")


def _file_check(check_id: str, path: str, value: object) -> dict:
    return {
        "check_id": check_id,
        "type": "file_sha256",
        "path": path,
        "sha256": sha256_bytes(canonical_bytes(value) + b"\n"),
    }


def make_product_spec(request: dict, store: ContentStore, current: datetime) -> dict:
    request_bytes = canonical_bytes(request) + b"\n"
    request_ref = store.put_bytes(
        request_bytes,
        ref_id=f"ref:request:{RUN_ID}",
        kind="evidence",
        media_type="application/json",
    )
    system_state = {
        "run_id": RUN_ID,
        "status": "CANDIDATE_NOT_CANONICAL",
        "evidence_policy": "CARRY_FORWARD_EXISTING_PASS_NO_REDUNDANT_REVALIDATION",
        "components": {
            "total-field": "PASS_FORMAL_DARK_LAUNCH_9_OF_9_CARRIED_FORWARD",
            "xiaoj-intent-field-9107": "PASS_HEALTHZ_PRODUCT_EDGE_INCOMPLETE_CARRIED_FORWARD",
            "odoo-18": "RUNNING_IDENTITY_PACKET_EDGE_INCOMPLETE_CARRIED_FORWARD",
            "pos": "SOURCE_CANDIDATE_NOT_DEPLOYED",
            "community-membership": "DEFERRED_PRE_ACTIVATION_READY",
            "committee-governance": "CANDIDATE_REFERENCE_ONLY",
            "local-llm-msi": "STATIC_PASS_LOCAL_DEVELOPMENT_CANDIDATE",
            "cloud-candidate": "ISOLATED_STATIC_PASS_LOCAL_ACCEPTANCE_REQUIRED",
            "website": "PASS_DEPLOY_READY_NOT_DEPLOYED",
        },
        "canonical_v2_sha256": CANONICAL_SHA256,
        "nlp_adapter_commit": NLP_COMMIT,
        "runtime_mutation": False,
    }
    product_map = {
        "root": "wuchang-total-field-product-system",
        "governance_entry": "total-field",
        "human_entry": "founder-or-authorized-member-client",
        "intent_authority": "xiaoj-intent-field-9107",
        "business_system": "odoo-18",
        "store_projection": "pos",
        "public_interest_domain": "wuchang-community-association",
        "candidate_layers": ["local-llm-msi", "constrained-cloud-candidate"],
        "receiver_targets": ["taiji01-linux", "authorized-linux-device"],
        "identity_rule": "reference-only identity packet; no member plaintext",
    }
    reconstruction_contract = {
        "mode": "equivalent_state",
        "receiver": "w7tp-python-receiver@0.1.0",
        "required_inputs": [request_ref["ref_id"]],
        "required_local_resolution": [
            "resolve current Total Field canonical record",
            "map canonical fields without renaming their meaning",
            "resolve current source manifest and memory index by local authority",
            "issue Total Field receipt only after local comparison accepts the candidate",
        ],
        "forbidden_substitutions": [
            "ordinary file movement",
            "compression or backup alone",
            "cloud ciphertext synchronization",
            "download-side decryption",
            "LLM prompt without packet-carried reconstruction and verification",
        ],
        "canonical_promotion": "LOCAL_TOTAL_FIELD_ONLY",
    }
    return {
        "d1_identity": {
            "identity_id": "identity:founder:chiang-cheng-lung",
            "founder": request["authority"]["founder"],
            "system_authority": "W7TP inventor, Founder, and accountable natural person",
            "actor_role": "founder",
            "trust_domain": "wuchang-total-field",
        },
        "d2_intent": {
            "intent_id": f"intent:{RUN_ID}",
            "system_name": "五常總場產品系統根封包",
            "target_equivalent_state": request["d1_intent"]["direct_result"],
            "product_contract": [
                request["d1_intent"]["completion_rule"],
                request["d5_execution"]["root_packet_rule"],
                request["d5_execution"]["receiver_rule"],
                "總場、小J、Odoo、POS、社區、管委會、會員主權AI與Linux節點由單一根封套統攝",
            ],
        },
        "d3_state": {
            "state_id": f"state:{RUN_ID}:cloud-candidate",
            "lifecycle": "cloud-candidate-local-reconstruction-required",
            "components": [
                {"component_id": "total-field", "role": "governance-verification", "version": "canonical-v2-ref", "state": system_state["components"]["total-field"], "dependencies": []},
                {"component_id": "xiaoj-intent-field", "role": "intent-authority", "version": "9107", "state": system_state["components"]["xiaoj-intent-field-9107"], "dependencies": ["total-field"]},
                {"component_id": "odoo", "role": "business-and-membership-system", "version": "18", "state": system_state["components"]["odoo-18"], "dependencies": ["total-field", "xiaoj-intent-field"]},
                {"component_id": "pos", "role": "cafe-store-projection", "version": "candidate", "state": system_state["components"]["pos"], "dependencies": ["odoo"]},
                {"component_id": "community", "role": "public-interest-industry-domain", "version": "candidate", "state": system_state["components"]["community-membership"], "dependencies": ["total-field", "odoo"]},
                {"component_id": "committee", "role": "community-governance-domain", "version": "candidate", "state": system_state["components"]["committee-governance"], "dependencies": ["total-field", "odoo"]},
                {"component_id": "local-llm", "role": "local-development-candidate", "version": "ollama-candidate", "state": system_state["components"]["local-llm-msi"], "dependencies": ["xiaoj-intent-field"]},
                {"component_id": "cloud-candidate", "role": "deidentified-candidate-expansion", "version": "governed-dual-channel-v1", "state": system_state["components"]["cloud-candidate"], "dependencies": ["total-field", "xiaoj-intent-field"]},
                {"component_id": "linux-fabric", "role": "receiver-and-node-fabric", "version": "candidate", "state": "LOCAL_RECONSTRUCTION_REQUIRED", "dependencies": ["total-field"]},
            ],
        },
        "d4_topology": {
            "coordinate_system": "W7TP-D3-identity-context-node-network-coordinate",
            "nodes": [
                {"node_id": "founder-client", "kind": "authorized-human-entry", "locator": "logical://founder/client", "capabilities": ["submit_intent", "confirm_governance"]},
                {"node_id": "caddy-gateway", "kind": "https-gateway", "locator": "logical://taiji01/caddy/443", "capabilities": ["route_request"]},
                {"node_id": "intent-field-9107", "kind": "intent-authority", "locator": "logical://taiji01/intent-field/9107", "capabilities": ["normalize_intent", "route_candidate"]},
                {"node_id": "total-field", "kind": "governance-verifier", "locator": "logical://taiji01/total-field", "capabilities": ["govern", "verify", "seal"]},
                {"node_id": "odoo-8069", "kind": "business-runtime", "locator": "logical://taiji01/odoo/8069", "capabilities": ["business_projection"]},
                {"node_id": "pos-node", "kind": "store-projection", "locator": "logical://wuchang-cafe/pos", "capabilities": ["cafe_projection"]},
                {"node_id": "msi-local-llm", "kind": "local-candidate-compute", "locator": "logical://msi/ollama", "capabilities": ["generate_candidate"]},
                {"node_id": "cloud-candidate", "kind": "constrained-candidate", "locator": "logical://cloud/deidentified-candidate", "capabilities": ["fill_bounded_candidate"]},
                {"node_id": "linux-receiver", "kind": "model-free-receiver", "locator": "logical://authorized-linux/receiver", "capabilities": ["lookup", "reconstruct", "verify"]},
            ],
            "transitions": [
                {"from": "founder-client", "to": "caddy-gateway", "condition": "authorized request"},
                {"from": "caddy-gateway", "to": "intent-field-9107", "condition": "route /wuchang/intent-field"},
                {"from": "intent-field-9107", "to": "total-field", "condition": "bounded candidate handoff"},
                {"from": "intent-field-9107", "to": "msi-local-llm", "condition": "local candidate route"},
                {"from": "intent-field-9107", "to": "cloud-candidate", "condition": "deidentified constrained route"},
                {"from": "total-field", "to": "odoo-8069", "condition": "governed business projection"},
                {"from": "odoo-8069", "to": "pos-node", "condition": "authorized store projection"},
                {"from": "total-field", "to": "linux-receiver", "condition": "local reconstruction authorized"},
            ],
        },
        "d5_resource": {
            "evidence": [
                {"evidence_id": "evidence:founder-request", "kind": "request-packet", "ref": request_ref["ref_id"], "sha256": request_ref["sha256"]},
                {"evidence_id": "evidence:canonical-v2", "kind": "canonical-reference", "ref": request["d2_state"]["known_canonical_locator"], "sha256": CANONICAL_SHA256},
                {"evidence_id": "evidence:nlp-adapter", "kind": "git-commit", "ref": f"git:{NLP_COMMIT}"},
                {"evidence_id": "evidence:route", "kind": "lookup-route", "ref": "CODE_GENERATION/code.generation.patch.v1"},
            ],
            "receiver": {"name": "w7tp-python-receiver", "version": "0.1.0", "model_free": True},
            "prerequisites": [
                "Python 3.11 or newer",
                "local content-addressed request reference",
                "new or empty receiver target",
                "local nonce replay ledger",
                "Total Field canonical mapping before promotion",
            ],
            "references": [
                request_ref,
                {"ref_id": "ref:canonical:w7tp-v2", "kind": "codebook", "sha256": CANONICAL_SHA256, "size_bytes": None, "media_type": "text/markdown", "required": False, "disclosure": "reference_only"},
            ],
            "operations": [
                {"operation_id": "op:create-root", "type": "mkdir", "target": "w7tp-system-root"},
                {"operation_id": "op:materialize-request", "type": "materialize_ref", "target": "w7tp-system-root/source-request.json", "ref_id": request_ref["ref_id"]},
                {"operation_id": "op:system-state", "type": "write_json", "target": "w7tp-system-root/system-state.json", "value": system_state},
                {"operation_id": "op:product-map", "type": "write_json", "target": "w7tp-system-root/product-map.json", "value": product_map},
                {"operation_id": "op:reconstruction-contract", "type": "write_json", "target": "w7tp-system-root/reconstruction-contract.json", "value": reconstruction_contract},
            ],
        },
        "d6_governance": {
            "authority": "Founder-authorized cloud candidate; local Total Field acceptance required",
            "allow_actions": ["reconstruct_candidate", "verify_candidate"],
            "deny_actions": HARD_DENIES,
            "data_rules": [
                request["d7_risk"]["source_preservation"],
                request["d7_risk"]["execution_boundary"],
                "member identity and protected codebooks remain reference-only",
                "canonical write remains unauthorized",
            ],
        },
        "d7_verification": {
            "acceptance_model": "equivalent_state",
            "canonical_ref": f"{request['d2_state']['known_canonical_locator']}@sha256:{CANONICAL_SHA256}",
            "reconstruction_conditions": [
                "resolve the exact Founder request by SHA-256",
                "materialize only into a distinct receiver target",
                "execute every packet-carried equivalence check",
                "keep cloud output candidate-only until local Total Field mapping accepts it",
            ],
            "equivalence_checks": [
                {"check_id": "check:root-exists", "type": "path_exists", "path": "w7tp-system-root"},
                {"check_id": "check:request-exact", "type": "file_sha256", "path": "w7tp-system-root/source-request.json", "sha256": request_ref["sha256"]},
                _file_check("check:state-exact", "w7tp-system-root/system-state.json", system_state),
                _file_check("check:map-exact", "w7tp-system-root/product-map.json", product_map),
                _file_check("check:contract-exact", "w7tp-system-root/reconstruction-contract.json", reconstruction_contract),
                {"check_id": "check:no-runtime-mutation", "type": "json_pointer_equals", "path": "w7tp-system-root/system-state.json", "pointer": "/runtime_mutation", "expected": False},
                {"check_id": "check:promotion-local-only", "type": "json_pointer_equals", "path": "w7tp-system-root/reconstruction-contract.json", "pointer": "/canonical_promotion", "expected": "LOCAL_TOTAL_FIELD_ONLY"},
            ],
        },
        "d8_envelope": {
            "packet_id": f"packet:{RUN_ID}:{uuid.uuid4()}",
            "parent_packet_id": None,
            "created_at": _utc(current),
            "expires_at": _utc(current + timedelta(days=7)),
            "nonce": secrets.token_hex(24),
            "protocol": {"name": "W7TP-8D-GT", "version": "product-candidate-v0.1"},
            "integrity": {"algorithm": "sha256", "packet_sha256": ""},
            "verification": {"required_checks": ["envelope_hash", "references", "reconstruction", "equivalence", "governance"]},
            "governance": {"status": "CANDIDATE_NOT_CANONICAL", "total_field_receipt_ref": None},
        },
    }


def run(request_path: Path, output_root: Path) -> dict:
    if output_root.exists() and any(output_root.iterdir()):
        raise SystemExit(f"STATE=HOLD_TARGET_NOT_EMPTY path={output_root}")
    output_root.mkdir(parents=True, exist_ok=True)
    request = load_json(request_path)
    if request.get("run_id") != RUN_ID:
        raise SystemExit("STATE=HOLD_RUN_ID_MISMATCH")
    store = ContentStore(output_root / "content-store")
    packet = build_packet(make_product_spec(request, store, datetime.now(timezone.utc)))
    packet_path = atomic_write_json(output_root / "W7TP_PRODUCT_SYSTEM_ROOT_PACKET.json", packet)
    receipt = reconstruct_packet(
        packet,
        store,
        output_root / "local-reconstruction",
        ReplayGuard(output_root / "replay-ledger"),
    )
    receipt_path = atomic_write_json(output_root / "TOTAL_FIELD_RECEIPT_CANDIDATE.json", receipt)
    result = {
        "STATE": "PASS_PRODUCT_SYSTEM_ROOT_PACKET_GENERATED",
        "RUN_ID": RUN_ID,
        "ROOT_PACKET": str(packet_path.resolve()),
        "PACKET_SHA256": packet["d8_envelope"]["integrity"]["packet_sha256"],
        "ROOT_PACKET_FILE_SHA256": sha256_bytes(packet_path.read_bytes()),
        "TOTAL_FIELD_RECEIPT": str(receipt_path.resolve()),
        "TOTAL_FIELD_RECEIPT_SHA256": sha256_bytes(receipt_path.read_bytes()),
        "CANONICAL_STATUS": "CANDIDATE_NOT_CANONICAL",
        "NEXT": "LOCAL_TOTAL_FIELD_CANONICAL_MAPPING",
    }
    atomic_write_json(output_root / "RESULT.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.request, args.output_root), ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
